﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Xml;
using System.Xml.Linq;
using System.IO;
using System.Threading;

namespace WebRequest1
{

 
     partial class E621Main
    {
       
        
        public static string E621Builder(string[] tags)
        {
            //If we have a null set of strings, produce an error
            if (tags[0] == null)
            {

                Console.WriteLine("NO TAGS ENTERED! Thats BAD!!!");
                return null;
            }

            //Start the new string
            StringBuilder query = new StringBuilder();

            //Init  query URL with first tag            
            query.AppendFormat("{0}{1}", e621BaseQuery, tags[0]);

            //loop through tag array
            for (int i = 1; i < tags.Length; i++)
            {
                //Is this tag null?
                if (tags[i] == null)
                {
                    //Exit loop 
                    break;
                }

                query.AppendFormat("+{0}", tags[i]);
            }
            query.Append(searchLimit);
            return query.ToString();



        }
        /*
        //saves out the file to the directory
        private static void saveFile(List<XElement> xmlNodes, string directory)
        {

            string fileID;
            string fileURL;
            string artist;
            string fileType;
            WebClient wc = new WebClient();
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < xmlNodes.Count; i++)
            {
                sem.WaitOne();
                fileID   =      xmlNodes[i].Element("id").Value.ToString();
                fileURL  =      xmlNodes[i].Element("file_url").Value.ToString();
                artist   =      xmlNodes[i].Element("artist").Value.ToString();
                fileType =      xmlNodes[i].Element("file_ext").Value.ToString();
                sb.AppendFormat("{0}{1}-{2}.{3}", directory, artist, fileID, fileType);
                Console.WriteLine("The file name will be: {0}{1}-{2}.{3}", directory, artist, fileID, fileType);

                wc.DownloadFile(fileURL, sb.ToString());

                sb = null;

            }
            
            foreach (XElement element in xmlNodes)
            {

                fileID = element.Element("id").Value.ToString();
                fileURL = element.Element("file_url").Value.ToString();
                artist = element.Element("artist").Value.ToString();
                fileType = element.Element("file_ext").Value.ToString();

                
                sb.AppendFormat("{0}{1}-{2}.{3}", directory, artist, fileID, fileType);
                Console.WriteLine("The file name will be: {0}{1}-{2}.{3}", directory, artist, fileID, fileType);

                wc.DownloadFile(fileURL, sb.ToString());

                sb = null;
            }

    
        }
        */
       static void saveFile(XElement node, string directory)
        {
            sem.WaitOne();
            Console.WriteLine("I am working!");
            string fileID;
            string fileURL;
            string artist;
            string fileType;
            WebClient wc = new WebClient();
            StringBuilder sb = new StringBuilder();

            fileID = node.Element("id").Value.ToString();
            fileURL = node.Element("file_url").Value.ToString();
            artist = node.Element("artist").Value.ToString();
            fileType = node.Element("file_ext").Value.ToString();
            sb.AppendFormat("{0}{1}-{2}.{3}", directory, artist, fileID, fileType);
            Console.WriteLine("The file name will be: {0}{1}-{2}.{3}", directory, artist, fileID, fileType);

            wc.DownloadFile(fileURL, sb.ToString());
            sem.Release();
        }
        static void saveFile(Object obj)
        {
            Console.WriteLine("{0} is waiting in line...", Thread.CurrentThread.Name);
            sem.WaitOne();
            WebClient wc = new WebClient();
            FileObject myfile = (FileObject)obj;        
            
            Console.WriteLine("{0} enters exectuion", Thread.CurrentThread.Name);
            Console.WriteLine(" The file name will be" + myfile.dlDirectory);

            wc.DownloadFile(myfile.url, myfile.dlDirectory);

            Console.WriteLine("{0} is leaving execution", Thread.CurrentThread.Name);
            sem.Release();
        }

        //iterates the next request from last request
        private static WebRequest nextE621Request(string[] tags, string beforeID)
        {
            string query = E621Builder(tags);
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("{0}{1}{2}", query, beforeIDBase, beforeID);


            return WebRequest.Create(sb.ToString());
        }

        //Displays menu for Command line. Returns int for action in main program line
        public static int DisplayMenu()
        {
            

            Console.WriteLine("Welcome to the E521 Downloader! Please choose an option below:");
            Console.WriteLine("[1] Search E621");
            Console.WriteLine("[2] Sign in");
            Console.WriteLine("[3] Edit BlackList tags");
            Console.WriteLine("[4] View Download directory");
            Console.WriteLine("[5] Load USer Values");
            Console.WriteLine("[6] Edit User Values");

            ConsoleKeyInfo input = Console.ReadKey();

            return int.Parse(input.KeyChar.ToString());                       
        }

        //Changes User Prefs.
        private static void editUserValues()
        {
            bool dirfound;
            do
            {
                
                Console.WriteLine("What directory do you want the next search to use?");
                string newDir = Console.ReadLine();
                if (System.IO.Directory.Exists(newDir))
                {
                    Properties.Settings.Default.directory = newDir;
                    Properties.Settings.Default.Save();
                    dirfound = true;
                }
                else
                {
                    Console.WriteLine("Invalid Directory!");
                    dirfound = false;
                }
            } while (!dirfound);

            


        }

        //Loads stored User Prefs
        private static string loadUserValues()
        {
            Console.WriteLine();
            return Properties.Settings.Default.directory;

        }

        //Redisplay menu
       private static bool repeatMenu()
        {
            ConsoleKeyInfo key;
            Console.WriteLine("Continue?(y/n) ");
            do
            {
                key = Console.ReadKey();
                if(key.Key != ConsoleKey.Y && key.Key != ConsoleKey.N)
                {
                    Console.WriteLine("Incorrect, try again!");
                }

            } while (key.Key != ConsoleKey.Y && key.Key != ConsoleKey.N);
            if(key.Key == ConsoleKey.Y)
            {
                return true;
            }
            else
            {
                return false;
            }
            
        }

        private static void parseQueryResults( string query)
        {

        }

       
    }
}

