﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebRequest1
{
    class Image
    {

        public string url { get; set; }
        public string dlDirectory { get; set; }


    }
    


}
