﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace WebRequest1
{
    /*
    class SavedSearch
    {
        //Name of the searche
        string searchName { get => searchName; set => searchName = value; }

        //Name of
        string searchDir
        {
            get => searchName;

            set
            {
                if (File.Exists(value))
                {
                    searchDir = value;
                }
                else
                {
                    //throw new sys
                }

            }


        }

        List<string> searchTags { get => searchTags; }     
        List<string> returnedIDs { get => returnedIDs; }


        

        

        
    }*/
}
